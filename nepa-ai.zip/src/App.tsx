import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Brain, Code, Globe, Zap, Image as ImageIcon, MessageSquare, ShieldCheck, ChevronRight } from 'lucide-react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ChatInput } from './components/ChatInput';
import { ChatMessage } from './components/ChatMessage';
import { AIPulse } from './components/AIPulse';
import { sendMessage, type ChatMessage as ChatMessageType } from './services/geminiService';
import { useAuth } from './context/AuthContext';
import { addMessage, createChat, subscribeToMessages } from './lib/firestore';

export default function App() {
  const { user, loading: authLoading, signIn } = useAuth();
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Subscribe to real-time messages when chat changes
  useEffect(() => {
    if (user && currentChatId) {
      const unsubscribe = subscribeToMessages(user.uid, currentChatId, (newMessages) => {
        setMessages(newMessages as any);
      });
      return unsubscribe;
    } else {
      setMessages([]);
    }
  }, [user, currentChatId]);

  const handleSendMessage = async (text: string, image?: { data: string; mimeType: string }) => {
    if (!user) {
      await signIn();
      return;
    }

    let chatId = currentChatId;
    
    // Create new chat if none exists
    if (!chatId) {
      const title = text.slice(0, 30) + (text.length > 30 ? '...' : '');
      const newChatId = await createChat(user.uid, title);
      chatId = newChatId || null;
      setCurrentChatId(chatId);
    }

    if (!chatId) return;

    // Save user message
    await addMessage(user.uid, chatId, 'user', text, image);
    setIsLoading(true);

    try {
      // Use current message history for context
      const chatHistoryForAI = messages.map(msg => ({
        role: msg.role,
        parts: msg.parts,
        timestamp: msg.timestamp
      }));

      const response = await sendMessage(text, chatHistoryForAI, image);
      
      // Save AI response with grounding metadata
      await addMessage(user.uid, chatId, 'model', response.text, undefined, response.groundingMetadata);
    } catch (error) {
      console.error(error);
      const errorText = "SYSTEM ERROR: NEPA AI encountered a connectivity issue. Please ensure your configuration is correct.";
      await addMessage(user.uid, chatId, 'model', errorText);
    } finally {
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="h-screen bg-neutral-950 flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen bg-neutral-950 flex items-center justify-center relative overflow-hidden p-6">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(37,99,235,0.1),transparent_50%)]" />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-[2.5rem] p-10 relative z-10 shadow-2xl"
        >
          <div className="flex flex-col items-center text-center mb-10">
            <div className="bg-blue-600 p-4 rounded-3xl mb-6 shadow-xl shadow-blue-600/20">
              <Sparkles size={40} className="text-white fill-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-3">Welcome to NEPA AI</h2>
            <p className="text-neutral-500 leading-relaxed font-sans">
              Sign in with your Google account to start your journey into advanced AI innovation.
            </p>
          </div>

          <button 
            onClick={() => signIn()}
            className="w-full py-4 px-6 bg-white text-black font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-neutral-200 transition-all shadow-xl active:scale-95"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-5 h-5" />
            Sign in with Google
          </button>

          <div className="mt-8 flex items-center gap-3 px-4 py-3 bg-neutral-950/50 rounded-2xl border border-neutral-800">
            <ShieldCheck size={16} className="text-blue-500" />
            <span className="text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Encrypted & Secure Session</span>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-neutral-950 text-neutral-200 overflow-hidden font-sans">
      <Sidebar 
        isOpen={isSidebarOpen} 
        currentChatId={currentChatId}
        onChatSelect={(id) => setCurrentChatId(id)}
        onNewChat={() => setCurrentChatId(null)} 
      />

      <main className="flex-1 flex flex-col min-w-0 relative">
        <Header 
          isSidebarOpen={isSidebarOpen} 
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} 
        />

        <div className="flex-1 overflow-y-auto scrollbar-hide">
          <AnimatePresence mode="wait">
            {!currentChatId && messages.length === 0 ? (
              <motion.div 
                key="welcome"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="min-h-full flex flex-col items-center justify-center p-8 text-center"
              >
                <div className="relative mb-8">
                   <motion.div 
                     animate={{ rotate: [0, 360], scale: [1, 1.1, 1] }}
                     transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                     className="absolute -inset-10 bg-blue-500/20 blur-3xl opacity-50"
                   />
                   <div className="bg-gradient-to-tr from-blue-600 to-indigo-600 p-6 rounded-[2.5rem] shadow-2xl relative">
                     <Sparkles size={40} className="text-white fill-white" />
                   </div>
                </div>
                
                <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4 text-white">
                  Design the future with <br />
                  <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-blue-400 bg-clip-text text-transparent animate-gradient-x underline-offset-8">
                    NEPA AI
                  </span>
                </h1>
                
                <p className="text-neutral-500 text-lg max-w-xl mx-auto leading-relaxed mb-10">
                  Advanced vision, reasoning, and creativity. <br />
                  Now with real-time memory and persistence.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
                  {[
                    { icon: <Brain size={20} />, title: "Contextual Memory", desc: "NEPA remembers your project across sessions." },
                    { icon: <Globe size={20} />, title: "Vision Layer", desc: "Process and analyze images with precision." },
                    { icon: <Zap size={20} />, title: "Flash Inference", desc: "Optimized for the lowest possible latency." }
                  ].map((feature, i) => (
                    <motion.button
                      key={i}
                      whileHover={{ scale: 1.02 }}
                      onClick={() => handleSendMessage(`Tell me about your ${feature.title}`)}
                      className="p-5 bg-neutral-900/40 border border-neutral-800 rounded-3xl hover:bg-neutral-800/60 hover:border-blue-500/30 transition-all text-left"
                    >
                      <div className="p-2 bg-neutral-800 rounded-xl w-fit mb-3 text-blue-500">
                         {feature.icon}
                      </div>
                      <h3 className="font-bold text-sm mb-1 text-white">{feature.title}</h3>
                      <p className="text-[11px] text-neutral-500 leading-snug">{feature.desc}</p>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <div className="flex flex-col py-8 pb-40">
                {messages.map((msg, i) => (
                  <ChatMessage key={i} message={msg} />
                ))}
                {isLoading && <AIPulse />}
                <div ref={messagesEndRef} />
              </div>
            )}
          </AnimatePresence>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-neutral-950 via-neutral-950/90 to-transparent pointer-events-none">
          <div className="max-w-4xl mx-auto pointer-events-auto">
            <ChatInput 
              onSend={handleSendMessage} 
              isLoading={isLoading} 
            />
          </div>
        </div>
      </main>
    </div>
  );
}
