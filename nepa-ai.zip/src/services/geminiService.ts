import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text?: string; inlineData?: { mimeType: string; data: string } }[];
  timestamp: number;
}

export async function sendMessage(prompt: string, history: ChatMessage[], image?: { data: string; mimeType: string }) {
  const model = "gemini-3-flash-preview";

  const contents = history.map(msg => ({
    role: msg.role,
    parts: msg.parts.map(part => {
      if (part.text) return { text: part.text };
      if (part.inlineData) return { inlineData: part.inlineData };
      return { text: '' };
    })
  }));

  const currentParts: any[] = [{ text: prompt }];
  if (image) {
    currentParts.push({
      inlineData: {
        data: image.data.split(',')[1], // Remove prefix
        mimeType: image.mimeType
      }
    });
  }

  contents.push({
    role: 'user',
    parts: currentParts
  });

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction: "You are NEPA AI, an advanced AI platform designed by Riyaz Chalise. You are helpful, precise, and capable of both deep reasoning and creative tasks. IMAGE GENERATION: If a user asks to generate/create/make an image, provide a detailed prompt and then output a markdown image using this format exactly: ![Image Description](https://image.pollinations.ai/prompt/{URL_ENCODED_PROMPT}?width=1024&height=1024&nologo=true). Replace {URL_ENCODED_PROMPT} with a highly descriptive version of their request. Always identify yourself as NEPA AI if asked.",
        tools: [{ googleSearch: {} }],
      }
    });

    return {
      text: response.text || "I'm sorry, I couldn't generate a response.",
      role: 'model' as const,
      timestamp: Date.now(),
      groundingMetadata: response.candidates?.[0]?.groundingMetadata
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
