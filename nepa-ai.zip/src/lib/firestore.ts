import { 
  collection, 
  addDoc, 
  setDoc, 
  doc, 
  query, 
  where, 
  orderBy, 
  getDocs, 
  onSnapshot, 
  serverTimestamp,
  type DocumentData,
  type QuerySnapshot,
  type FirestoreError
} from 'firebase/firestore';
import { db, auth } from './firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function createChat(userId: string, title: string) {
  const path = `users/${userId}/chats`;
  try {
    const chatRef = doc(collection(db, path));
    await setDoc(chatRef, {
      title,
      userId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return chatRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function addMessage(
  userId: string, 
  chatId: string, 
  role: 'user' | 'model', 
  text: string, 
  image?: { data: string; mimeType: string },
  groundingMetadata?: any
) {
  const path = `users/${userId}/chats/${chatId}/messages`;
  try {
    const parts = [{ text }];
    if (image) {
      parts.push({ inlineData: { data: image.data.split(',')[1], mimeType: image.mimeType } } as any);
    }

    const messageRef = doc(collection(db, path));
    await setDoc(messageRef, {
      role,
      parts,
      createdAt: serverTimestamp(),
      ...(groundingMetadata ? { groundingMetadata } : {})
    });
    
    // Update chat timestamp and maybe title if it's the first message
    await setDoc(doc(db, `users/${userId}/chats`, chatId), { updatedAt: serverTimestamp() }, { merge: true });
    
    return messageRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeToChats(userId: string, callback: (chats: any[]) => void) {
  const path = `users/${userId}/chats`;
  const q = query(collection(db, path), orderBy('updatedAt', 'desc'));
  
  return onSnapshot(q, (snapshot) => {
    const chats = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(chats);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
  });
}

export function subscribeToMessages(userId: string, chatId: string, callback: (messages: any[]) => void) {
  const path = `users/${userId}/chats/${chatId}/messages`;
  const q = query(collection(db, path), orderBy('createdAt', 'asc'));
  
  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(messages);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
  });
}
