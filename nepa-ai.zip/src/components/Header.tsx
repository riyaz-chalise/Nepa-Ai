import { Menu, Zap, UserCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface HeaderProps {
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
}

export function Header({ onToggleSidebar, isSidebarOpen }: HeaderProps) {
  return (
    <header className="flex items-center justify-between px-6 py-4 bg-neutral-950/80 backdrop-blur-md border-b border-neutral-900 sticky top-0 z-50">
      <div className="flex items-center gap-4">
        <button 
          onClick={onToggleSidebar}
          className="p-2 hover:bg-neutral-900 rounded-xl text-neutral-400 hover:text-white transition-colors"
        >
          <Menu size={22} />
        </button>
        
        <div className="flex items-center gap-2">
          <div className="relative">
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 bg-blue-500 blur-xl opacity-20"
            />
            <div className="bg-blue-600 p-1.5 rounded-lg">
              <Zap size={20} className="text-white fill-white" />
            </div>
          </div>
          <span className="text-xl font-bold tracking-tight text-white font-sans">
            NEPA <span className="text-blue-500">AI</span>
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-full text-xs font-bold text-neutral-400">
           <span className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
           PREMIUM
        </div>
        <button className="p-1 rounded-full border border-neutral-800 hover:border-neutral-600 transition-colors">
          <UserCircle size={32} className="text-neutral-400" />
        </button>
      </div>
    </header>
  );
}
