import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { User, Bot, Copy, Check, Globe } from 'lucide-react';
import { motion } from 'motion/react';

interface MessagePart {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
  };
}

interface ChatMessageProps {
  message: {
    role: 'user' | 'model';
    parts: MessagePart[];
    groundingMetadata?: any;
  };
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const { role, parts, groundingMetadata } = message;
  const content = parts.find(p => p.text)?.text || '';
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const groundingChunks = groundingMetadata?.groundingChunks || [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex w-full gap-4 p-6 ${
        role === 'model' ? 'bg-slate-900/50 backdrop-blur-sm border-y border-slate-800' : ''
      }`}
    >
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
        role === 'user' ? 'bg-indigo-600' : 'bg-emerald-600'
      }`}>
        {role === 'user' ? <User size={18} className="text-white" /> : <Bot size={18} className="text-white" />}
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold uppercase tracking-widest text-slate-500">
            {role === 'user' ? 'You' : 'Nepa AI'}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="p-1 hover:bg-slate-800 rounded transition-colors text-slate-500 hover:text-slate-300"
              title="Copy to clipboard"
            >
              {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
            </button>
          </div>
        </div>
        
        <div className="prose prose-invert prose-slate max-w-none prose-p:leading-relaxed prose-pre:bg-slate-950 prose-pre:border prose-pre:border-slate-800">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {content}
          </ReactMarkdown>
        </div>

        {role === 'model' && groundingChunks.length > 0 && (
          <div className="mt-8 pt-6 border-t border-slate-800">
            <div className="flex items-center gap-2 mb-4 text-xs font-bold text-slate-500 uppercase tracking-widest">
              <Globe size={14} />
              <span>Foundations & Sources</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {groundingChunks.map((chunk: any, i: number) => chunk.web && (
                <a
                  key={i}
                  href={chunk.web.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 hover:border-indigo-500/50 transition-all group flex flex-col gap-1"
                >
                  <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-tighter truncate">
                    {new URL(chunk.web.uri).hostname}
                  </span>
                  <span className="text-xs text-slate-300 font-medium line-clamp-1 group-hover:text-white transition-colors">
                    {chunk.web.title || chunk.web.uri}
                  </span>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
};
