import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';

export function AIPulse() {
  return (
    <div className="flex items-center gap-6 py-10 px-6 max-w-4xl mx-auto w-full bg-neutral-900/20 rounded-3xl border border-neutral-800/30">
      <div className="w-10 h-10 rounded-full bg-blue-600/20 flex items-center justify-center shrink-0">
        <motion.div
           animate={{ 
             scale: [1, 1.2, 1],
             opacity: [0.5, 1, 0.5]
           }}
           transition={{ duration: 2, repeat: Infinity }}
        >
          <Sparkles size={20} className="text-blue-400" />
        </motion.div>
      </div>

      <div className="flex-1 space-y-4">
        <div className="space-y-3">
          <motion.div 
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="h-4 bg-neutral-800 rounded-full w-3/4"
          />
          <motion.div 
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: 0.2 }}
            className="h-4 bg-neutral-800 rounded-full w-1/2"
          />
        </div>
      </div>
    </div>
  );
}
