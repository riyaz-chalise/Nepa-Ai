import { useState, useEffect } from 'react';
import { MessageSquare, Plus, History, Settings, ExternalLink, ShieldCheck, LogOut } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { useAuth } from '../context/AuthContext';
import { subscribeToChats } from '../lib/firestore';

interface SidebarProps {
  onNewChat: () => void;
  onChatSelect: (id: string) => void;
  currentChatId: string | null;
  isOpen: boolean;
}

export function Sidebar({ onNewChat, onChatSelect, currentChatId, isOpen }: SidebarProps) {
  const { user, signOut } = useAuth();
  const [chats, setChats] = useState<{ id: string; title: string }[]>([]);

  useEffect(() => {
    if (user) {
      const unsubscribe = subscribeToChats(user.uid, (fetchedChats) => {
        setChats(fetchedChats as any);
      });
      return unsubscribe;
    }
  }, [user]);

  return (
    <motion.aside 
      initial={false}
      animate={{ width: isOpen ? 280 : 0, opacity: isOpen ? 1 : 0 }}
      className="h-full bg-neutral-950 border-r border-neutral-900 overflow-hidden flex flex-col"
    >
      <div className="p-4">
        <button 
          onClick={onNewChat}
          className="w-full flex items-center gap-3 px-4 py-3 bg-neutral-900 border border-neutral-800 rounded-2xl text-neutral-300 hover:text-white hover:bg-neutral-800 transition-all group"
        >
          <div className="p-1 bg-neutral-800 rounded-lg group-hover:bg-neutral-700 transition-colors">
            <Plus size={18} />
          </div>
          <span className="font-semibold text-sm">New Chat</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-2 space-y-1 py-4 scrollbar-hide">
        <div className="px-4 mb-2 flex items-center gap-2">
          <History size={14} className="text-neutral-500" />
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-neutral-500">Recent</span>
        </div>
        
        {chats.length > 0 ? (
          chats.map((chat) => (
            <button 
              key={chat.id} 
              onClick={() => onChatSelect(chat.id)}
              className={cn(
                "w-full text-left px-4 py-3 rounded-xl transition-all text-sm flex items-center gap-3",
                currentChatId === chat.id 
                  ? "bg-neutral-900 text-white border border-neutral-800" 
                  : "text-neutral-400 hover:text-white hover:bg-neutral-900"
              )}
            >
              <MessageSquare size={16} />
              <span className="truncate">{chat.title || 'Uitled Chat'}</span>
            </button>
          ))
        ) : (
          <div className="px-4 py-8 text-center text-neutral-600 text-xs italic">
            No history yet
          </div>
        )}
      </div>

      <div className="p-4 border-t border-neutral-900 space-y-1">
        <div className="flex items-center gap-2 px-4 py-2 text-neutral-500 text-[10px] mb-2 font-bold tracking-widest">
          <ShieldCheck size={14} />
          <span>NEPA SECURE v3.1</span>
        </div>
        
        <button className="w-full text-left px-4 py-2.5 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-900 transition-all text-sm flex items-center gap-3">
          <Settings size={16} />
          <span>Settings</span>
        </button>
        
        {user && (
          <button 
            onClick={() => signOut()}
            className="w-full text-left px-4 py-2.5 rounded-xl text-red-400/70 hover:text-red-400 hover:bg-red-500/5 transition-all text-sm flex items-center gap-3"
          >
            <LogOut size={16} />
            <span>Sign Out</span>
          </button>
        )}
        
        <div className="pt-4 px-2">
          <div className="p-3 bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800 rounded-2xl">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-[10px] text-neutral-300 font-bold uppercase tracking-wider">NEPA Engine Active</span>
            </div>
            <p className="text-[10px] text-neutral-500 leading-tight">
              Powered by Riyaz Chalise's Advanced Vision Layer
            </p>
          </div>
        </div>
      </div>
    </motion.aside>
  );
}
