import React from 'react';
import { Send, Image as ImageIcon, Paperclip } from 'lucide-react';
import { motion } from 'motion/react';

interface ChatInputProps {
  onSend: (message: string) => void;
  isLoading: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSend, isLoading }) => {
  const [input, setInput] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSend(input);
      setInput('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto w-full p-4 pb-8">
      <form
        onSubmit={handleSubmit}
        className="relative group bg-slate-900 border border-slate-700 rounded-2xl shadow-xl transition-all duration-300 focus-within:border-indigo-500 focus-within:shadow-indigo-500/10"
      >
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask Nepa AI anything..."
          rows={1}
          className="w-full bg-transparent text-slate-100 p-4 pr-24 resize-none focus:outline-none placeholder:text-slate-500 min-h-[56px] max-h-48 scrollbar-hide"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSubmit(e);
            }
          }}
        />
        
        <div className="absolute right-2 bottom-2 flex items-center gap-1">
          <button
            type="button"
            className="p-2 text-slate-500 hover:text-slate-300 transition-colors rounded-lg hover:bg-slate-800"
          >
            <Paperclip size={20} />
          </button>
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className={`p-2 rounded-xl transition-all duration-300 ${
              input.trim() && !isLoading
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 hover:scale-105 active:scale-95'
                : 'text-slate-600 bg-slate-800/50'
            }`}
          >
            {isLoading ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              >
                <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full" />
              </motion.div>
            ) : (
              <Send size={20} />
            )}
          </button>
        </div>
      </form>
      <p className="text-[10px] text-center mt-3 text-slate-500 uppercase tracking-widest font-semibold opacity-50">
        Nepa AI can make mistakes. Check important info.
      </p>
    </div>
  );
};
